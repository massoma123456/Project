
export const FooterComponent = () => {
  return (
    <div>
        <footer className='footer'>
            <span> All rights reserved 2023 by swb</span>
        </footer>
    </div>
  )
}
